export const sessionjson = {
  secret: 'keyboard cat',
  saveUninitialized: false,
  resave: false,
  cookie: { maxAge: 60000 },
};
